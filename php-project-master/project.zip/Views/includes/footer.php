		<script src="../../public/js/jquery-1.11.1.min.js"></script>
		<script src="../../public/js/bootstrap.min.js"></script>    
		<script src="../../public/js/chart.min.js"></script>
		<script src="../../public/js/chart-data.js"></script>
		<script src="../../public/js/easypiechart.js"></script>
		<script src="../../public/js/easypiechart-data.js"></script>
		<script src="../../public/js/bootstrap-datepicker.js"></script>
		<script src="../../public/js/custom.js"></script>
	</body>
</html>