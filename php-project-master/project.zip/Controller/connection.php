<?php
$server="localhost";
$username="root";
$password="ashraf";
$dbname="cafeteria";
$conn=new mysqli($server,$username,$password,$dbname);

