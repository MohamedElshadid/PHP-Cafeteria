<?php

include_once("config.php");

class Client{

}